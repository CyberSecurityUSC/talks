# Reverse Engineering talk

## Running the web server
Literally 0 dependencies, any static server will do (e.g. nginx).
If you're running this locally, `./run` starts a server only you can access.
`./run` requires python3.

## Examples
Sources are not available for the examples (excluding `printf-src`).
Figure it out yourself!

## ORDER
1. printf-src
2. printf
3. if
4. while
5. argv
6. math
7. switch
8. recurse
9. arrays

## Bombs
Binaries for you to try yourself.
Used with permission of Dr. Matthews (https://cse.sc.edu/~matthews/).
Originally from http://csapp.cs.cmu.edu/3e/labs.html.

Hint: more than half of the phases were covered in the talk.
