#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BOLD    "\033[1m"
#define RED     "\033[31m"
#define RESET   "\033[0m"
void error(void) {
  puts(BOLD RED "YOU LOSE." RESET);
  exit(1);
}

int main(void) {
  int input;
  size_t len = 0;
  fputs("Enter an integer: ", stdout);
  fscanf(stdin, "%d", &input);
  if (input != 43151) {
    error();
  }
  puts("You won!");
}
