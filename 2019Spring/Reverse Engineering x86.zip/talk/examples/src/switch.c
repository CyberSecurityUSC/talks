#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BOLD    "\033[1m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define BLUE    "\033[34m"
#define RESET   "\033[0m"
void error(void) {
  puts(BOLD RED "YOU LOSE." RESET);
  exit(1);
}

int main(void) {
  int n, i = 4;
  fputs("Enter the password: ", stdout);
  scanf("%d", &n);
  switch (n) {
    case 0:
      puts(BLUE "Nope." RESET);
      break;
    case 1:
      puts(BLUE "Fallthrough!" RESET);
    case 2:
      puts(BLUE "No." RESET);
      break;
    case 3:
      puts("You won!");
      break;
    default:
      puts(BLUE "Also wrong." RESET);
  }
}
