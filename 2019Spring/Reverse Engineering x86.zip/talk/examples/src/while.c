#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BOLD    "\033[1m"
#define RED     "\033[31m"
#define RESET   "\033[0m"
void error(void) {
  puts(BOLD RED "YOU LOSE." RESET);
  exit(1);
}

int main(void) {
  int n, i = 4;
  fputs("Enter the password: ", stdout);
  scanf("%d", &n);
  while (n < 50) {
    n += 5;
    --i;
  }
  if (n != 52 || i != 0) error();
  puts("You won!");
}
