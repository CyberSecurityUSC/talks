#include <stdio.h>
#include <stdlib.h>

#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define BLUE    "\033[34m"
#define RESET   "\033[0m"

int recursive(int n) {
  if (n == 0 || n == 1) return 1;
  return recursive(n - 1) + recursive(n - 2);
}

int main(int argc, char *argv[]) {
  if (recursive(argc) == 55 && recursive(strtol(argv[1], NULL, 10)) == 8) {
    puts(GREEN "You won!" RESET);
  } else {
    puts(RED "YOU LOSE." RESET);
  }
}
