#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BOLD    "\033[1m"
#define RED     "\033[31m"
#define RESET   "\033[0m"
void error(void) {
  puts(BOLD RED "YOU LOSE." RESET);
  exit(1);
}

int main(int argc, char *argv[]) {
  if (argc != 2 || strcmp(argv[1], "another secret message"))
    error();
  puts("You won!");
}
